#' Generic plot scaling methods
#'
#' @docType package
#' @name package-scales
#' @aliases scales package-scales
#' @import munsell plyr Rcpp
#' @useDynLib scales
NULL
